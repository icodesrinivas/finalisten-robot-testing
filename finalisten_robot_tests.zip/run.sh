#!/bin/bash
robot FinalistenTestCases/